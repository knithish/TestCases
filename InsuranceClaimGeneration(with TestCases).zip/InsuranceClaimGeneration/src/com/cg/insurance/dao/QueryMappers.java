package com.cg.insurance.dao;

public interface QueryMappers {
	public static final String insertQuery="insert into claim(?,?,?,?,?,?,?,?)";
	public static final String getpolicy_number="select  POLICY_NUMBER from claim;";
	public static final String checkAccess="select * from user_role where user_name=?";
	public static final String insert_User="insert into user_role values(?,?,?)";
	public static final String selectQuery="select user_name from user_role";
	public static final String viewAllClaims=" select claim_number, claim_type, policy_number from claim where policy_number IN (select policy_number from policy where account_number IN (select account_number from account where user_name =?))";
	public static final String viewAllPolicies = "SELECT * FROM POLICY WHERE ACCOUNT_NUMBER=(SELECT ACCOUNT_NUMBER FROM ACCOUNT WHERE USER_NAME=(SELECT USER_NAME FROM USER_ROLE WHERE USER_NAME=?))";
	public static final String fetch_USer="select * from agentuserrelation where agentID=?";
	
	
	public static final String EXECUTE_QUERY = "Select * from question_table where  BUSINESS_SEGMENT=?";
	public static final String INSERT_CLAIM = "insert into claim values(?,?,?,?,?,?,?,?)";
	public static final String INSERT_POLICY_DETAILS = "insert into policy_details values(?,?,?)";
	public static final String CHECK_CLAIM_USING_POLICY_NO = "Select * from claim where policy_number=?";
	public static final String GEN_SEQ = "select claimno.nextval from dual";
	public static final String Get_BusinessSegment="select business_segment from account where user_name =?";
}
