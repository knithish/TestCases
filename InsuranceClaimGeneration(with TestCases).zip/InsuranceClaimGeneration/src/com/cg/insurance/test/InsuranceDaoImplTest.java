package com.cg.insurance.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.dao.IInsuranceDAO;
import com.cg.insurance.dao.InsuranceDaoImpl;
import com.cg.insurance.exception.InsuranceClaimException;

public class InsuranceDaoImplTest {
static IInsuranceDAO dao=null;
static UserBean userbean=null;
static ClaimBean claimbean=null;
static PolicyBean policyBean=null;
static PolicyDetailsBean policyDetailsBean=null;
static QuestionBean questionBean=null;
static AgentUserBean agentUserBean=null;
 static List<PolicyDetailsBean> policylist =null;
//static Iterator<PolicyDetailsBean> iterator = policyDetailsList.iterator();
@BeforeClass
public static void initialize() {
	System.out.println("in before class");
	dao = new InsuranceDaoImpl();
	userbean=new UserBean();
	claimbean=new ClaimBean();
	policyBean=new PolicyBean();
	questionBean=new QuestionBean();
	agentUserBean=new AgentUserBean();
	policyDetailsBean=new PolicyDetailsBean();
	policylist =new ArrayList<>();
}

@Test
	public void testCheckAccess() throws IOException, SQLException, InsuranceClaimException {
	
		assertNotNull(dao.checkAccess(userbean));
		userbean.getUsername();
		userbean.getPassword();
		userbean.getRoleCode();
	}

	@Test
	public void testAddUser() {
		assertNotNull( userbean);
		userbean.setUsername("USER001");
		userbean.setPassword("001user");
		userbean.setRoleCode("USER");
	}

	@Test
	public void testViewAllClaims() throws InsuranceClaimException, IOException, SQLException {
		assertNotNull(dao.viewAllClaims("USER001"));
		claimbean.getClaimReason();
		claimbean.getAccidentLocationStreet();
		claimbean.getAccidentCity();
		claimbean.getAccidentState();
		claimbean.getAccidentZip();
		claimbean.getClaimNumber();
		claimbean.getClaimReason();
		claimbean.getPolicyNumber();
		
	}

	@Test
	public void testViewAllPolicy() throws IOException, InsuranceClaimException, SQLException {
		assertNotNull(dao.viewAllPolicy("USER001"));
		policyBean.getAccountNumber();
		policyBean.getPolicyNumber();
		policyBean.getPolicyPremium();
	}

	@Test
	public void testFetchUsers() throws IOException, InsuranceClaimException, SQLException {
		assertNotNull(dao.fetchUsers("USER001"));
		agentUserBean.getAgentID();
		agentUserBean.getUserID();
	}

	@Test
	public void testGetQuestions() throws IOException, InsuranceClaimException, SQLException {
		assertNotNull(dao.fetchUsers("USER001"));
		questionBean.getQuestion();
	}

	@Test
	public void testCreateClaim() throws ClassNotFoundException, Exception {
		
		claimbean.setClaimReason("Accident");
		claimbean.setAccidentLocationStreet("Ramanthapur");
		claimbean.setAccidentCity("Hyderabad");
		claimbean.setAccidentState("Telengana");
		claimbean.setAccidentZip("500013");
		claimbean.setPolicyNumber(1000105);
		claimbean.setClaimNumber("B180");
		claimbean.setClaimType("Medical Negligence Claims");
		
		policyDetailsBean.setPolicyNumber(1000105);
		policyDetailsBean.setQuestionId("BA101");
		policyDetailsBean.setAnswer("Light");
		policylist.add(policyDetailsBean);
		assertNotNull(dao.createClaim(claimbean,policylist));
	}

	@Test
	public void testGetBusinessSegment() throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException {
		assertNotNull(dao.getBusinessSegment("USER001"));
		questionBean.getBusinessSegment();
		
	}

}
